# CareerFlowAI

AI-powered job automation platform for real-time job scraping, AI-driven matching, LinkedIn contact scoring, encrypted resume storage, and browser autofill extension.

## Features

- Real-time job scraping (Google Careers, etc.)
- AI job matching using NLP (Compromise)
- Secure resume encryption (AES-256)
- LinkedIn contact discovery/scoring
- Chrome extension for autofill on portals
- Responsive React frontend (navy/gold, Asana-inspired)
- MongoDB + Redis persistence
- Supabase user database

## Setup

1. `npm install`
2. Add `.env` with correct keys (see template).
3. Start backend: `npm start`
4. Start frontend: `npm run dev`
5. Load Chrome extension from `extension/`
6. Build for Netlify: `npm run build` (publish `dist/`)

## Testing

- Supabase: includes sample user row.
- LinkedIn: API calls are mocked if token missing.
- Job scrapers support Google Careers, Workable, Lever, Greenhouse.

## Security

- Resume encrypted at upload (AES-256)
- Input validation/sanitization
- Rate limiting on APIs
- Secure file upload

## Database

### Supabase Users Table

```sql
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  fullName TEXT,
  email TEXT,
  phone TEXT,
  resumePath TEXT,
  linkedinUrl TEXT,
  location TEXT
);
```

### MongoDB

Collections:
- jobs.listings: scraped jobs
- applications.queue: application status

## Chrome Extension

- Manifest v3
- Autofills Greenhouse, Workable, Lever forms
- Instructions: [extension-instructions.html](extension-instructions.html)

## License

MIT