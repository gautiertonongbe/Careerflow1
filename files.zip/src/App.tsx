import React, { useState } from 'react';
import axios from 'axios';
import './index.css';

const App: React.FC = () => {
  const [userId, setUserId] = useState('user123');
  const [companyUrl, setCompanyUrl] = useState('https://careers.google.com');
  const [location, setLocation] = useState('San Francisco');
  const [minMatchScore, setMinMatchScore] = useState(90);
  const [jobUrl, setJobUrl] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [company, setCompany] = useState('');
  const [resume, setResume] = useState<File | null>(null);
  const [jobs, setJobs] = useState<any[]>([]);
  const [contacts, setContacts] = useState<any[]>([]);
  const [message, setMessage] = useState('');

  const uploadResume = async () => {
    if (!resume) {
      setMessage('Please select a resume file');
      return;
    }
    const formData = new FormData();
    formData.append('resume', resume);
    formData.append('userId', userId);
    try {
      const res = await axios.post('/api/applications/upload-resume', formData);
      setMessage(res.data.message);
    } catch (error: any) {
      setMessage('Upload error: ' + error.response?.data?.error || error.message);
    }
  };

  const findJobs = async () => {
    try {
      const res = await axios.post('/api/applications/auto-apply', {
        userId,
        criteria: { companyUrl, location, minMatchScore }
      });
      setJobs(res.data.jobs);
      setMessage(`Found ${res.data.jobs.length} matching jobs`);
    } catch (error: any) {
      setMessage('Find jobs error: ' + error.response?.data?.error || error.message);
    }
  };

  const applyForJob = async () => {
    if (!jobUrl || !jobTitle || !company) {
      setMessage('Please enter job URL, title, and company');
      return;
    }
    try {
      const res = await axios.post('/api/applications/generate-application', {
        jobUrl,
        userId,
        jobTitle,
        company
      });
      chrome.storage.local.set({ applicationData: res.data.data }, () => {
        window.open(res.data.applyUrl, '_blank');
      });
      setMessage('Application generated, redirecting...');
    } catch (error: any) {
      setMessage('Apply error: ' + error.response?.data?.error || error.message);
    }
  };

  const findContacts = async () => {
    try {
      const res = await axios.post('/api/applications/linkedin-contacts', { userId, company });
      setContacts(res.data.contacts);
      setMessage(`Found ${res.data.contacts.length} LinkedIn contacts`);
    } catch (error: any) {
      setMessage('Contacts error: ' + error.response?.data?.error || error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-navy text-white p-4">
        <h1 className="text-2xl font-bold">CareerFlow AI</h1>
      </header>
      <main className="container mx-auto p-4">
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-navy">Upload Resume</h2>
          <div className="flex flex-col gap-2">
            <input
              type="text"
              value={userId}
              onChange={e => setUserId(e.target.value)}
              placeholder="User ID"
              className="p-2 border rounded"
            />
            <input
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={e => setResume(e.target.files?.[0] || null)}
              className="p-2 border rounded"
            />
            <button onClick={uploadResume} className="bg-gold text-navy p-2 rounded hover:bg-yellow-600">
              Upload Resume
            </button>
          </div>
        </section>
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-navy">Find Jobs</h2>
          <div className="flex flex-col gap-2">
            <input
              type="text"
              value={companyUrl}
              onChange={e => setCompanyUrl(e.target.value)}
              placeholder="Company URL (e.g., https://careers.google.com)"
              className="p-2 border rounded"
            />
            <input
              type="text"
              value={location}
              onChange={e => setLocation(e.target.value)}
              placeholder="Location (e.g., San Francisco)"
              className="p-2 border rounded"
            />
            <input
              type="number"
              value={minMatchScore}
              onChange={e => setMinMatchScore(Number(e.target.value))}
              placeholder="Minimum Match Score"
              className="p-2 border rounded"
            />
            <button onClick={findJobs} className="bg-gold text-navy p-2 rounded hover:bg-yellow-600">
              Find Jobs
            </button>
          </div>
          {jobs.length > 0 && (
            <ul className="mt-4 space-y-2">
              {jobs.map(job => (
                <li key={job.url} className="p-4 bg-white rounded shadow">
                  <span className="font-semibold">{job.title}</span> ({job.location}, Score: {job.matchScore})
                  <button
                    onClick={() => {
                      setJobUrl(job.url);
                      setJobTitle(job.title);
                      setCompany(job.companyUrl.split('/')[2]);
                      applyForJob();
                    }}
                    className="ml-4 bg-navy text-white p-2 rounded hover:bg-blue-800"
                  >
                    Apply
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-navy">Find LinkedIn Contacts</h2>
          <div className="flex flex-col gap-2">
            <input
              type="text"
              value={company}
              onChange={e => setCompany(e.target.value)}
              placeholder="Company Name (e.g., Google)"
              className="p-2 border rounded"
            />
            <button onClick={findContacts} className="bg-gold text-navy p-2 rounded hover:bg-yellow-600">
              Find Contacts
            </button>
          </div>
          {contacts.length > 0 && (
            <ul className="mt-4 space-y-2">
              {contacts.map(contact => (
                <li key={contact.profileUrl} className="p-4 bg-white rounded shadow">
                  {contact.name} (Score: {contact.score}) -{' '}
                  <a href={contact.profileUrl} target="_blank" className="text-navy underline">
                    Profile
                  </a>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-navy">Apply Directly</h2>
          <div className="flex flex-col gap-2">
            <input
              type="text"
              value={jobUrl}
              onChange={e => setJobUrl(e.target.value)}
              placeholder="Job URL"
              className="p-2 border rounded"
            />
            <input
              type="text"
              value={jobTitle}
              onChange={e => setJobTitle(e.target.value)}
              placeholder="Job Title"
              className="p-2 border rounded"
            />
            <input
              type="text"
              value={company}
              onChange={e => setCompany(e.target.value)}
              placeholder="Company"
              className="p-2 border rounded"
            />
            <button onClick={applyForJob} className="bg-gold text-navy p-2 rounded hover:bg-yellow-600">
              Apply
            </button>
          </div>
        </section>
        {message && <p className="text-navy">{message}</p>}
      </main>
      <footer className="bg-navy text-white p-4 text-center">
        <p>© 2025 CareerFlow AI. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;