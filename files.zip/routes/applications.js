const express = require('express');
const router = express.Router();
const puppeteer = require('puppeteer');
const cheerio = require('cheerio');
const { createClient } = require('@supabase/supabase-js');
const Redis = require('ioredis');
const { MongoClient } = require('mongodb');
const crypto = require('crypto');
const nlp = require('compromise');
const axios = require('axios');
const multer = require('multer');
const path = require('path');
const { Queue } = require('bull');

let supabase, redis, mongo;
try {
  supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
  redis = new Redis(process.env.REDIS_URL, { maxRetriesPerRequest: 3, reconnectOnError: () => true });
  mongo = new MongoClient(process.env.MONGODB_URL, { maxPoolSize: 10 });
} catch (error) {
  throw error;
}
const applicationQueue = new Queue('applications', process.env.REDIS_URL, { limiter: { max: 10, duration: 1000 } });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/resumes/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.pdf', '.doc', '.docx'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) cb(null, true);
    else cb(new Error('Invalid file type. Only PDF, DOC, DOCX allowed.'));
  },
  limits: { fileSize: 5 * 1024 * 1024 }
});

async function scrapeJobs(companyUrl, location) {
  try {
    const cacheKey = `jobs:${companyUrl}:${location || 'all'}`;
    const cached = await redis.get(cacheKey);
    if (cached) return JSON.parse(cached);

    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
      timeout: 60000
    });
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
    await page.goto(companyUrl, { waitUntil: 'networkidle2', timeout: 60000 });
    const content = await page.content();
    await browser.close();

    const $ = cheerio.load(content);
    const jobs = [];
    $('[class*="job"], [class*="career"], [class*="listing"], [class*="posting"]').each((i, el) => {
      const title = $(el).find('[class*="title"], h2, h3, h4, [id*="title"]').text().trim();
      const description = $(el).find('[class*="description"], p, [class*="details"]').text().trim();
      const url = $(el).find('a[href*="apply"], a[href*="job"], [class*="apply"]').attr('href')?.trim();
      const jobLocation = $(el).find('[class*="location"]').text().trim().toLowerCase() || 'unknown';
      if (title && url) {
        const fullUrl = url.startsWith('http') ? url : new URL(url, companyUrl).href;
        if (!location || jobLocation.includes(location.toLowerCase())) {
          jobs.push({ title, description, url: fullUrl, matchScore: 0, companyUrl, location: jobLocation, scrapedAt: new Date() });
        }
      }
    });

    if (jobs.length > 0) {
      await redis.set(cacheKey, JSON.stringify(jobs), 'EX', 3600);
      try {
        await mongo.connect();
        const db = mongo.db('jobs');
        await db.collection('listings').insertMany(jobs);
      } finally {
        await mongo.close();
      }
    }
    return jobs;
  } catch (error) {
    return [];
  }
}

async function findMatchingJobs(criteria, resume) {
  try {
    const companyUrl = criteria.companyUrl || 'https://careers.google.com';
    const location = criteria.location || '';
    const jobs = await scrapeJobs(companyUrl, location);
    if (!jobs.length) return [];

    const resumeDoc = nlp(resume);
    const resumeSkills = resumeDoc.topics().out('array').map(s => s.toLowerCase());
    const resumeExperience = resumeDoc.match('#Organization').out('array').length;

    const matchedJobs = jobs.map(job => {
      const jobDoc = nlp(job.description);
      const jobSkills = jobDoc.topics().out('array').map(s => s.toLowerCase());
      const skillMatch = resumeSkills.filter(skill => jobSkills.includes(skill)).length * 15;
      const experienceMatch = jobDoc.match('#Organization').out('array').length > resumeExperience ? 10 : 20;
      const locationMatch = job.location.toLowerCase().includes(location.toLowerCase()) ? 15 : 0;
      const matchScore = Math.min(skillMatch + experienceMatch + locationMatch, 100);
      return { ...job, matchScore };
    });
    return matchedJobs;
  } catch (error) {
    return [];
  }
}

async function generateApplicationData(userId, jobTitle, company) {
  try {
    const { data: user, error } = await supabase
      .from('users')
      .select('fullName, email, phone, resumePath, linkedinUrl, location')
      .eq('id', userId)
      .single();
    if (error) throw new Error(`User not found: ${error.message}`);

    const resumeContent = fs.readFileSync(user.resumePath, 'utf8');
    const cipher = crypto.createCipher('aes-256-cbc', process.env.ENCRYPTION_KEY);
    const encryptedResume = cipher.update(resumeContent, 'utf8', 'hex') + cipher.final('hex');

    const resumeDoc = nlp(resumeContent);
    const topSkills = resumeDoc.topics().out('array').slice(0, 2);
    const coverLetter = `Dear Hiring Manager,\nI am excited to apply for the ${jobTitle || 'position'} at ${company || 'your company'}. My experience in ${topSkills.join(' and ')} aligns with your needs. I have successfully [add specific achievement from resume]. I look forward to contributing to your team.\nSincerely,\n${user.fullName}`;

    return {
      fullName: user.fullName,
      email: user.email,
      phone: user.phone,
      resumePath: user.resumePath,
      encryptedResume,
      linkedinUrl: user.linkedinUrl,
      location: user.location,
      coverLetter
    };
  } catch (error) {
    throw error;
  }
}

router.post('/generate-application', async (req, res) => {
  try {
    const { jobUrl, userId, jobTitle, company } = req.body;
    if (!jobUrl || !userId) return res.status(400).json({ error: 'Job URL and User ID required' });

    const applicationData = await generateApplicationData(userId, jobTitle, company);
    await applicationQueue.add('generate-application', { jobUrl, applicationData }, { priority: 1 });
    res.json({
      success: true,
      applyUrl: jobUrl,
      data: applicationData,
      message: 'Redirect to apply URL with autofill data'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/auto-apply', async (req, res) => {
  try {
    const { userId, criteria } = req.body;
    if (!userId || !criteria) return res.status(400).json({ error: 'User ID and criteria required' });

    const { data: user } = await supabase.from('users').select('resumePath').eq('id', userId).single();
    if (!user) throw new Error('User not found');

    const resumeContent = fs.readFileSync(user.resumePath, 'utf8');
    const jobs = await findMatchingJobs(criteria, resumeContent);
    const highMatchJobs = jobs.filter(job => job.matchScore >= (criteria.minMatchScore || 90));

    await applicationQueue.add('auto-apply', { jobs: highMatchJobs, userId }, { priority: 2 });
    res.json({
      success: true,
      jobs: highMatchJobs,
      message: `Found ${highMatchJobs.length} jobs for redirection`
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/linkedin-contacts', async (req, res) => {
  try {
    const { userId, company } = req.body;
    if (!company) return res.status(400).json({ error: 'Company name required' });

    const cacheKey = `contacts:${company}`;
    const cached = await redis.get(cacheKey);
    if (cached) return res.json({ success: true, contacts: JSON.parse(cached) });

    if (!process.env.LINKEDIN_TOKEN) {
      const contacts = [
        { name: "John Doe", profileUrl: "https://linkedin.com/in/johndoe", score: 90, message: "..." }
      ];
      return res.json({ success: true, contacts });
    }

    const response = await axios.get('https://api.linkedin.com/v2/people-search', {
      headers: {
        Authorization: `Bearer ${process.env.LINKEDIN_TOKEN}`,
        'X-Restli-Protocol-Version': '2.0.0'
      },
      params: {
        q: 'peopleSearch',
        company,
        keywords: 'recruiter,hiring manager'
      }
    }).catch(error => {
      throw new Error('Failed to fetch LinkedIn contacts');
    });

    const contacts = response.data.elements.map(contact => {
      const score = contact.headline.toLowerCase().includes('recruiter') ? 90 : contact.headline.toLowerCase().includes('hiring') ? 85 : 80;
      return {
        name: contact.firstName + ' ' + contact.lastName,
        profileUrl: contact.publicProfileUrl || `https://linkedin.com/in/${contact.id}`,
        score,
        message: `Hi ${contact.firstName}, I'm interested in opportunities at ${company}. My background in [skills] aligns with your needs. Can we discuss further?`
      };
    });

    await redis.set(cacheKey, JSON.stringify(contacts), 'EX', 3600);
    res.json({ success: true, contacts });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/upload-resume', upload.single('resume'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No resume file uploaded' });

    const { userId } = req.body;
    const resumePath = req.file.path;
    await supabase.from('users').update({ resumePath }).eq('id', userId);

    res.json({
      success: true,
      resumePath,
      message: 'Resume uploaded successfully'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/queue-status', async (req, res) => {
  try {
    const stats = await redis.hgetall('queue:stats');
    res.json({ success: true, stats });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

applicationQueue.process('generate-application', async (job) => {
  try {
    const { jobUrl, applicationData } = job.data;
    await redis.hset('queue:stats', jobUrl, 'processed');
  } catch (error) {}
});

applicationQueue.process('auto-apply', async (job) => {
  try {
    const { jobs, userId } = job.data;
    for (const job of jobs) {
      await redis.hset('queue:stats', job.url, 'queued');
    }
  } catch (error) {}
});

module.exports = router;