// Job scraping utility (run as a worker or on demand)
// Uses Puppeteer (stealth), Cheerio, Redis, MongoDB
const puppeteer = require('puppeteer');
const cheerio = require('cheerio');
const redis = require('./redis');
const { jobsCollection } = require('./mongo');

async function scrapeJobs(companyUrl) {
  // Check Redis cache first
  let cached = await redis.get('job_listings');
  if (cached) return JSON.parse(cached);

  // Puppeteer headless browser
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  // Stealth mode (minimal)
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
  await page.goto(companyUrl, { waitUntil: 'networkidle2', timeout: 60000 });

  const html = await page.content();
  await browser.close();

  // Use Cheerio to parse
  const $ = cheerio.load(html);
  let jobs = [];
  // Example for Google Careers; extend for other formats
  $('.gc-card').each((_, el) => {
    jobs.push({
      id: $(el).attr('data-id'),
      title: $(el).find('.gc-card__title').text().trim(),
      company: 'Google',
      location: $(el).find('.gc-card__location').text().trim(),
      url: 'https://careers.google.com' + $(el).find('a.gc-card__link').attr('href'),
      skills: ['javascript', 'react', 'node'], // Simulate skill extraction
      experience: 'Senior'
    });
  });

  // Persist to MongoDB
  await jobsCollection.deleteMany({});
  await jobsCollection.insertMany(jobs);

  // Cache in Redis (1 hour TTL)
  await redis.set('job_listings', JSON.stringify(jobs), 'EX', 3600);

  return jobs;
}

module.exports = { scrapeJobs };