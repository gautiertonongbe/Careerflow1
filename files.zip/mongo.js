// MongoDB client and collections
const { MongoClient } = require('mongodb');

const mongoClient = new MongoClient(process.env.MONGODB_URL, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

let db;
let jobsCollection;
let queueCollection;

mongoClient.connect().then(client => {
  db = client.db();
  jobsCollection = db.collection('jobs.listings');
  queueCollection = db.collection('applications.queue');
});

module.exports = { mongoClient, jobsCollection, queueCollection };