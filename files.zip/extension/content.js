chrome.storage.local.get(['applicationData'], ({ applicationData }) => {
  if (!applicationData) {
    console.error('No application data found in chrome.storage.local');
    return;
  }

  console.log('Autofill started with data:', applicationData);

  const fields = {
    'input[name="full_name"], input[name="name"], input[id*="name"], input[placeholder*="name"]': applicationData.fullName,
    'input[name="email"], input[type="email"], input[id*="email"], input[placeholder*="email"]': applicationData.email,
    'input[name="phone"], input[type="tel"], input[id*="phone"], input[placeholder*="phone"]': applicationData.phone,
    'input[type="file"][name*="resume"], input[type="file"][name*="cv"], input[id*="resume"], input[placeholder*="resume"]': applicationData.resumePath
  };

  Object.entries(fields).forEach(([selector, value]) => {
    const input = document.querySelector(selector);
    if (input && value) {
      console.log(`Filling field ${selector} with value ${value}`);
      if (input.type === 'file') {
        fetch(value)
          .then(res => {
            if (!res.ok) throw new Error(`Fetch failed for ${value}: ${res.statusText}`);
            return res.blob();
          })
          .then(blob => {
            const file = new File([blob], 'resume.pdf', { type: 'application/pdf' });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            input.files = dataTransfer.files;
            input.dispatchEvent(new Event('change', { bubbles: true }));
            console.log(`Uploaded file to ${selector}`);
          })
          .catch(err => console.error(`File upload error for ${selector}:`, err));
      } else {
        input.value = value;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        console.log(`Set ${selector} to ${value}`);
      }
    } else {
      console.warn(`Field ${selector} not found or value missing`);
    }
  });
});